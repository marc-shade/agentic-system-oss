---
name: browser-tester
description: Interactive web application testing using Playwright and Chrome DevTools MCP. Use when asked to test web applications, verify UI functionality, check for console errors, validate network requests, or inspect running applications in the browser. Ideal for testing dashboards, APIs, form submissions, and interactive components.
---

# Browser Tester

## Overview

Provides comprehensive web application testing capabilities using Playwright automation and Chrome DevTools MCP integration. Enables verification of UI functionality, console error detection, network request inspection, screenshot capture, and interactive debugging.

## When to Use This Skill

Activate this skill when:
- Testing web applications at specific URLs (e.g., "test the dashboard at localhost:3101")
- Verifying UI elements work correctly (e.g., "check if all tabs function properly")
- Checking for console errors or warnings
- Validating network requests and API calls
- Inspecting page rendering and visual elements
- Taking screenshots for documentation or debugging
- Testing form submissions and user interactions
- Verifying responsive design across viewports

## Testing Workflow

### 1. Navigate to URL

Launch the browser and navigate to the target URL:

```bash
# Use chrome-devtools MCP to navigate
# The MCP handles browser lifecycle automatically
```

**Example user requests:**
- "Test the overnight automation dashboard at http://localhost:3101/overnight-automation"
- "Open the frontend at http://localhost:3001"

### 2. Initial Page Load Verification

Check for immediate issues:
- Console errors (red errors in DevTools Console)
- Network failures (4xx/5xx status codes)
- JavaScript exceptions
- Missing resources (404s for CSS/JS/images)
- Page render completion

**Testing checklist** (see `references/testing-checklist.md` for complete list):
- [ ] Page loads without errors
- [ ] No console errors or warnings
- [ ] All network requests return 2xx/3xx status
- [ ] Page renders visually as expected
- [ ] No missing images or broken resources

### 3. Interactive Element Testing

Test user interactions systematically:

**Tab Testing:**
- Click each tab in sequence
- Verify tab content loads
- Check for console errors after each click
- Validate data displays correctly

**Form Testing:**
- Fill form fields with test data
- Submit forms
- Verify validation messages
- Check network requests on submission

**Button Testing:**
- Click all interactive buttons
- Verify expected actions occur
- Check for API calls triggered
- Validate loading states and feedback

**Example workflow for dashboard testing:**
```
1. Navigate to dashboard URL
2. Wait for initial load
3. Check console for errors
4. Iterate through each tab:
   - Click tab
   - Wait for content to load
   - Verify data appears
   - Check console for errors
   - Check network panel for API calls
5. Take screenshot of each tab
6. Report findings
```

### 4. Network Request Analysis

Monitor and validate API calls:
- Request URLs and methods
- Response status codes
- Response data structure
- Request/response timing
- Failed requests

**Common issues to detect:**
- 404 errors for missing endpoints
- 500 errors from server failures
- Slow response times (>2 seconds)
- CORS errors
- Authentication failures

### 5. Console Error Detection

Categorize and report console messages:
- **Errors (red)**: Critical JavaScript failures
- **Warnings (yellow)**: Potential issues
- **Info (blue)**: Informational logs
- **Debug**: Development messages

**Report format:**
```
❌ Console Errors (3):
- TypeError: Cannot read property 'map' of undefined (Component.jsx:45)
- Failed to load resource: 404 /api/missing-endpoint
- Uncaught ReferenceError: foo is not defined

⚠️ Console Warnings (2):
- React Hook useEffect has a missing dependency
- DevTools failed to load source map

✅ No critical blocking errors
```

### 6. Visual Testing

Capture and verify visual elements:
- Take screenshots of key pages/states
- Verify layout and spacing
- Check responsive design
- Validate component rendering
- Compare against design specs (if provided)

**Screenshot locations:**
Save to `/tmp/` or user-specified location with descriptive names:
- `dashboard-overview.png`
- `temporal-health-tab.png`
- `error-state.png`

### 7. Report Generation

Provide comprehensive test results:

**Test Report Structure:**
```markdown
# Browser Test Results

**URL**: http://localhost:3101/overnight-automation
**Date**: 2025-10-24 14:30:00
**Status**: ✅ PASS / ❌ FAIL

## Summary
- Tabs tested: 5/5
- Console errors: 0
- Network failures: 0
- Screenshots captured: 5

## Detailed Findings

### Tab 1: Morning Report
- ✅ Loads correctly
- ✅ No console errors
- ✅ API endpoint returns data
- Screenshot: /tmp/morning-report.png

### Tab 2: Research Discoveries
- ✅ Loads correctly
- ⚠️ Warning: Empty state shown (no data yet)
- ✅ No console errors

## Issues Found
None - all tests passing!

## Recommendations
- Populate test data for Research Discoveries tab
- Add loading indicators for slow API calls
```

## MCP Integration

### Chrome DevTools MCP

The `chrome-devtools` MCP provides browser automation capabilities. Available through the MCP router.

**Key capabilities:**
- Navigate to URLs
- Execute JavaScript in page context
- Capture screenshots
- Monitor console messages
- Intercept network requests
- Evaluate page state

**Access pattern:**
```javascript
// MCP tools are available when skill is active
// Use through the enhanced-router MCP system
```

## Best Practices

### Systematic Testing Approach
1. Test top-to-bottom, left-to-right
2. Document findings as you go
3. Take screenshots before and after interactions
4. Note both successes and failures
5. Provide actionable recommendations

### Error Categorization
- **Critical**: Blocks core functionality
- **High**: Degrades user experience
- **Medium**: Visual or minor functional issues
- **Low**: Cosmetic or edge case issues

### Test Data Management
- Use realistic test data when possible
- Clean up test data after testing
- Don't expose sensitive data in screenshots
- Use placeholder credentials for auth testing

### Performance Considerations
- Note slow page loads (>3 seconds)
- Identify large network payloads (>1MB)
- Check for excessive API calls
- Monitor memory usage for long-running tests

## Resources

### references/testing-checklist.md
Comprehensive checklist of common web application test scenarios and verification points. Load this reference for detailed testing guidance.

### scripts/
Currently no automation scripts. Manual testing using MCP tools provides flexibility for diverse testing scenarios.

### assets/
Currently no test assets. Screenshots are generated dynamically during testing.
